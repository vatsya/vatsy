#!/usr/bin/python3
name="cmr"
print(name)
print(name*3)
print(name+"is a big university")
print(name[0])
print(name[1])
print(name[2])
