#!/usr/bin/python3
temperture=12 
while temperture<20:
	temp=input("are u cole: y/n")
	print(temperture)
	temperture=temperture+1
	if temp=="y":
	print("need coffee")
