#!/usr/bin/python3
import random
r=random.randint(1,6)
print(r)
