#!/usr/bin/python3
for i in range(0,20):
   if(i%2==0):
    print(i,"is an even num")
