#!/usr/bin/python
import random
r=random.randint(5,6)
print(r)
