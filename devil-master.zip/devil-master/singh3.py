#!/usr/bin/python3
# guess what this program does????
import random
r=random.randint(23,49) # gives random num
print(r)
print(47)
print(39)
print(35)
print(39)
print(35)
