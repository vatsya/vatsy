#!/usr/bin/python3
a=77
print(a)
print(a+5)
print(a-11)
print(a*12)
print(a%5)