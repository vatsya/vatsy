a="amrendra"
print(a)
print(a+"singh")
print(a[4])
print(a*4)
print(a[3])
