#!/usr/bin/python3
import random
count=0
r=0
while count <=100:
     roll=input("press r to roll")
     if rool ="r":
     	r=random.randint(1,6)
        count=count+r
     	print("random num ",r)
     	print("count",count)	