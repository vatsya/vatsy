a="pakistan"
print(a)
b=a+" murdabad"
print(b*99999)




